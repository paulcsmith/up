
# Changelog :)

## Format

Based on [Keep a Changelog].

## Versioning Policy

[Semantic Versioning Caret]

## Versions

### 0.7.0

#### Changed

* Crystal 0.26.1

#### Fixed

* #15 Fix heredoc usage when embedding blob; by @bcardiff; Thank you :)

### 0.6.1

#### Fixed

* Fixes VERSION

### 0.6.0

#### Changed

* Changes Crystal to 0.25.0.
* Sorts entries before rendering.

### 0.5.0

#### Changed

* Changes Crystal to 0.24.2.

[Keep a Changelog]: http://keepachangelog.com/en/1.0.0/
[Semantic Versioning Caret]: https://github.com/malform/semver-caret
